package t::lib::ShareDir;

use strict;

use vars qw{$VERSION @ISA};
BEGIN {
	$VERSION = '1.01';
	@ISA     = 'File::ShareDir';
}

1;
